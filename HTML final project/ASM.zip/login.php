<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Kiểm tra username và password có hợp lệ
    if ($username == "admin" && $password == "password") {
        echo "Đăng nhập thành công!";
    } else {
        echo "Đăng nhập thất bại!";
    }
}
?>
