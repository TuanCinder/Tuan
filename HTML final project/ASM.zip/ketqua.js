document.addEventListener("DOMContentLoaded", function() {
    const personalityItems = document.querySelectorAll(".result-list li");
    const personalityDetails = document.querySelector(".personality-details");
  
    personalityItems.forEach(function(item) {
      item.addEventListener("click", function() {
        const selectedPersonality = item.dataset.personality;
        const selectedContent = document.getElementById(selectedPersonality);
        
        // Ẩn tất cả các nội dung tính cách
        const allContents = document.querySelectorAll(".personality-content");
        allContents.forEach(function(content) {
          content.style.display = "none";
        });
        
        // Hiển thị nội dung tính cách được chọn
        selectedContent.style.display = "block";
        
        // Cuộn trang đến nội dung tính cách được hiển thị
        selectedContent.scrollIntoView({ behavior: 'smooth' });
      });
    });
  });
  