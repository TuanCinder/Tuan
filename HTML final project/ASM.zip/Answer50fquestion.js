var totalScore = 0; // Tổng điểm của trắc nghiệm

// Câu hỏi phần JP
// Câu hỏi 1
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (25 / 3); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}


// Câu hỏi 2
var answer2 = "a"; // Câu trả lời của câu hỏi 

if (answer2 === "a") {
  totalScore += (25 / 3); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}


// Câu hỏi 3
var answer3 = "a"; // Câu trả lời của câu hỏi 

if (answer3 === "a") {
  totalScore += (25 / 3); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 4
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (25 / 3); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
 // Câu hỏi 5
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (25 / 3); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 6
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (25 / 3); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 7
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (25 / 3); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 8
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (25 / 3); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 9
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (25 / 3); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 10
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (25 / 3); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 11
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (25 / 3); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 12
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (25 / 3); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
console.log("Tổng điểm: " + totalScore);
// Câu hỏi phần SN
// Câu hỏi 1
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 2
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 3
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 4
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 5
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 1
} else {
  score = 0;
}
//Câu hỏi 6
var answer1 = "a"; // Câu trả lời của câu hỏi 1

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 1
} else {
  score = 0;
}
// Câu hỏi 7
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 8
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 9
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 10
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 11
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 12
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 13
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 14
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
console.log("Tổng điểm: " + totalScore);
// Câu hỏi phần FT
// Câu hỏi 1
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 2
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 3
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 4
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 5
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 1
} else {
  score = 0;
}
//Câu hỏi 6
var answer1 = "a"; // Câu trả lời của câu hỏi 1

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 1
} else {
  score = 0;
}
// Câu hỏi 7
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 8
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 9
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 10
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 11
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 12
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 13
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 14
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (50 / 7); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
console.log("Tổng điểm: " + totalScore);

// Câu hỏi EI
// Câu hỏi 1
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (10); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 2
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (10); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 3
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (10); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 4
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (10); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 5
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (10); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 6
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (10); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 7
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (10); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 8
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (10); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 19
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (10); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
// Câu hỏi 10
var answer1 = "a"; // Câu trả lời của câu hỏi 

if (answer1 === "a") {
  totalScore += (10); // Tăng điểm cho câu hỏi 
} else {
  score = 0;
}
console.log("Tổng điểm: " + totalScore);
