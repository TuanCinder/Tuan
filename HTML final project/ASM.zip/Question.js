function submitAnswers() {
    // Lấy giá trị của các câu hỏi
    const answers = [
      document.querySelector('input[name=q1]:checked').value,
      document.querySelector('input[name=q2]:checked').value,
      document.querySelector('input[name=q3]:checked').value,
      document.querySelector('input[name=q4]:checked').value,
      // ... và các câu hỏi khác tương tự
    ];

    // Tính điểm cho từng nhóm tính cách
    const groupScores = {
      E: 0,
      I: 0,
      S: 0,
      N: 0,
      T: 0,
      F: 0,
      J: 0,
      P: 0
    };

    for (let i = 0; i < answers.length; i++) {
      groupScores[answers[i]]++;
    }

    // Xác định nhóm tính cách dựa trên điểm số
    let result = '';

    if (groupScores.E > groupScores.I) {
      result += 'E';
    } else {
      result += 'I';
    }

    if (groupScores.S > groupScores.N) {
      result += 'S';
    } else {
      result += 'N';
    }

    if (groupScores.T > groupScores.F) {
      result += 'T';
    } else {
      result += 'F';
    }

    if (groupScores.J > groupScores.P) {
      result += 'J';
    } else {
      result += 'P';
    }

    // Hiển thị kết quả
    const resultDiv = document.getElementById('result');
    resultDiv.innerHTML = `Kết quả của bạn là: ${result}`;
  }