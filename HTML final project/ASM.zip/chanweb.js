// Chặn sự kiện nhấn phím
document.addEventListener('keydown', function(e) {
    // Danh sách mã phím bạn muốn chặn
    var forbiddenKeys = [
      'F1' ,      //Phím F1
      'F2' ,      //Phím F2
      'F3' ,      //Phím F3
      'F4' ,      //Phím F4
      'F6' ,      //Phím F6
      'F7' ,      //Phím F7
      'F8' ,      //Phím F8 
      'F9' ,      //Phím F9
      'F10' ,      //Phím F10
      'F12' ,      //Phím F12  
      'Escape',   // Phím Escape
      'F5',       // Phím F5
      'F11',      // Phím F11
      'Control',  // Phím Control (Ctrl)
      'Alt',      // Phím Alt
      'Shift',    // Phím Shift
      'Meta'      // Phím Windows hoặc Command (Mac)
    ];
  
    // Kiểm tra nếu người dùng nhấn một trong các phím bị cấm
    if (forbiddenKeys.includes(e.key)) {
      e.preventDefault(); // Ngăn chặn hành động mặc định của phím
      // Hiển thị thông báo hoặc cảnh báo cho người dùng (tùy chọn)
      alert('Không được phép sử dụng phím tắt hoặc chuyển trang web!');
    }
  });
  
  // Chặn sự kiện click chuột phải
  document.addEventListener('contextmenu', function(e) {
    e.preventDefault(); // Ngăn chặn hành động mặc định của chuột phải
    // Hiển thị thông báo hoặc cảnh báo cho người dùng (tùy chọn)
    alert('Không được phép sử dụng chuột phải để chuyển trang web!');
  });
  